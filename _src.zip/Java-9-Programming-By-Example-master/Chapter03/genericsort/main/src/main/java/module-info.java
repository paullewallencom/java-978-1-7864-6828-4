//module packt.java9.by.example.ch03.main{
//        requires packt.java9.by.example.ch03.quick;
//        requires packt.java9.by.example.ch03;
//        requires packt.java9.by.example.ch03.support;
//        }