package packt.java9.by.example.ch03;

public interface Swapper {
    /**
     * Swapper two elements
     * @param i index of the first element to swap
     * @param j index of other element to swap the first with
     */
    void swap(int i, int j);
}
