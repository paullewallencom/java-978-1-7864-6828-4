package packt.java9.by.example.mybusiness.product;

public class Product {
}
